import React from 'react'
import './Header.css'

const Header = () => {
  return (
    <div className='header'>
      <div className="header-contents">
        <h2>Create some amazing memories! </h2>
        <p>Here is a compilation of some fun, affordable and budget-friendly places to visit in the summeer around Toronto and the GTA. Use this resource to choose your favourite spot, use the built-in calculation feature to add the number of tickets intended for your trip to calculate total ticket cost for your family and friends.</p>
      <button>View Options</button>
      </div>
    </div>
  )
}

export default Header
