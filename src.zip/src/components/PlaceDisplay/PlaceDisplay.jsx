import React, { useContext } from 'react';
import './PlaceDisplay.css';  // Corrected import path
import { StoreContext } from '../../context/StoreContext';
import PlaceItem from '../PlaceItem/PlaceItem';

const PlaceDisplay = ({ category }) => {
    const { place_list } = useContext(StoreContext);

    return (
        <div className='place-display' id='place-display'>
            <h2>Top Activity Destinations</h2>
            <div className="place-display-list">
                {place_list.map((item, index)=>{
                    
                    if (category===item.category){
                    //category="All" || add this before 'category===item' when needed
                        
                        return <PlaceItem key={index} id={item._id} name={item.name} description={item.description} price={item.price} image={item.image}/>
                    }
                })}
            </div>


        
        </div>
    );
}

export default PlaceDisplay;
