import React, { useState } from 'react';
import './NavBar.css';
import { assets } from '../../assets/assets';

const NavBar = () => {

    const [menu, setMenu] = useState("Home");

  return (
    <div className='navbar'>
        <img src={assets.logo} alt="Logo" className="logo" />
        <ul className="navbar-menu">
            <li onClick={()=>setMenu("Home")} className={menu==="Home"?"active":""}>Home</li>
            <li onClick={()=>setMenu("Places")} className={menu==="Places"?"active":""}>Places</li>
            <li onClick={()=>setMenu("Contact-Us")} className={menu==="Contact-Us"?"active":""}>Contact-Us</li>
            <li onClick={()=>setMenu("Maps")} className={menu==="Maps"?"active":""}>Maps</li>
        </ul>

        <div className="navbar-right">
            <img src={assets.search_icon} alt="Search" className="navbar-search-icon" />
            <div className="navbar-basket">
                <img src={assets.basket_icon} alt="Basket" />
                <div className="dot"></div>
            </div>
            <button className="navbar-signin">Sign In</button>
        </div>
    </div>
  );
}

export default NavBar;
