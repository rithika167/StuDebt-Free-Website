import basket_icon from './basket_icon.png'
import logo from './logo.png'
import header_img from './headerPic.png'
import search_icon from './search_icon.png'

import menu_1 from './menu_1.png'
import menu_2 from './menu_2.png'
import menu_3 from './menu_3.png'
import menu_4 from './menu_4.png'

import place_1 from './cats.png'
import place_2 from './activate1.png'
import place_3 from './ago.png'
import place_4 from './archery.png'
import place_5 from './bowling.png'
import place_6 from './claw.png'
import place_7 from './climbing.png'
import place_8 from './distillery.png'
import place_9 from './drive-in.png'
import place_10 from './gardiner.png'
import place_11 from './golf.png'
import place_12 from './honda.png'
import place_13 from './mi.png'
import place_14 from './pursuitOCR.png'
import place_15 from './roller.png'
import place_16 from './secretcity.png'
import place_17 from './trampoline.png'
import place_18 from './tubing.png'
import place_19 from './upla.png'
import place_20 from './wonderland.png'
import place_21 from './belfountain.png'
import place_22 from './buttermilk.png'
import place_23 from './crawford.png'
import place_24 from './cup-saucer.png'
import place_25 from './decew.png'
import place_26 from './elora.png'
import place_27 from './guild.png'
import place_28 from './tob.png'
import place_29 from './tulip.png'




import add_icon_white from './add_icon_white.png'
import add_icon_green from './add_icon_green.png'
import remove_icon_red from './remove_icon_red.png'
import app_store from './app_store.png'
import play_store from './play_store.png'
import linkedin_icon from './linkedin_icon.png'
import facebook_icon from './facebook_icon.png'
import twitter_icon from './twitter_icon.png'
import cross_icon from './cross_icon.png'
import selector_icon from './selector_icon.png'
import rating_starts from './rating_starts.png'
import profile_icon from './profile_icon.png'
import bag_icon from './bag_icon.png'
import logout_icon from './logout_icon.png'
import parcel_icon from './parcel_icon.png'

export const assets = {
    logo,
    basket_icon,
    header_img,
    search_icon,
    rating_starts,
    add_icon_green,
    add_icon_white,
    remove_icon_red,
    app_store,
    play_store,
    linkedin_icon,
    facebook_icon,
    twitter_icon,
    cross_icon,
    selector_icon,
    profile_icon,
    logout_icon,
    bag_icon,
    parcel_icon
}

export const menu_list = [
    {
        menu_name: "Activities",
        menu_image: menu_1
    },
    {
        menu_name: "Parks",
        menu_image: menu_2
    },
    {
        menu_name: "Food Places",
        menu_image: menu_3
    },
    {
        menu_name: "Shops/Boutiques",
        menu_image: menu_4
    }]

export const place_list = [
    {
        _id: "1",
        name: "4Cats Arts Studio",
        image: place_1,
        price: 15,
        description: "Address: 1386 Bayview Ave #1, Toronto, ON M4G 3A5",
        category: "Activities"
    },
    {
        _id: "2",
        name: "Activate",
        image: place_2,
        price: 28,
        description: "Address: 1980 Eglinton Ave E Unit 2, Scarborough, ON M1L 2M6",
        category: "Activities"
        
    }, {
        _id: "3",
        name: "Art Gallery of Ontario (AGO)",
        image: place_3,
        price: 0,
        description: "Address: 317 Dundas St W, Toronto, ON M5T 1G4",
        category: "Activities"
       
    }, {
        _id: "4",
        name: "Archer's Arena",
        image: place_4,
        price: 48,
        description: "Address: 1140 Sheppard Ave W Suite 4, North York, ON M3K 2A2",
        category: "Activities"
       
    }, {
        _id: "5",
        name: "Splitsville",
        image: place_5,
        price: 20,
        description: "Address: 191 Marycroft Ave, Woodbridge, ON L4L 5Y3",
        category: "Activities"
       
    }, {
        _id: "6",
        name: "Claw World",
        image: place_6,
        price: 25,
        description: "Address: 1571 Sandhurst Cir Unit 109, Toronto, ON M1V 1V2",
        category: "Activities"
        
    }, {
        _id: "7",
        name: "Aspire Climbing",
        image: place_7,
        price: 30,
        description: "Address: 231 Trade Valley Drive Unit D-F, Woodbridge, ON L4H 3N6",
        category: "Activities"
       
    }, {
        _id: "8",
        name: "Distillery District: Outdoor Cinema",
        image: place_8,
        price: 20,
        description: "Address: 101 Yorkville Ave, Toronto, ON, M5R 1C1",
        category: "Activities"

    }, {
        _id: "9",
        name: "Drive-5 Oakville",
        image: place_9,
        price: 14,
        description: "Address: 2332 Ninth Line, Oakville, ON L6H 7G9",
        category: "Activities"
       
    }, {
        _id: "10",
        name: "Gardiner Museum Pottery",
        image: place_10,
        price: 20,
        description: "Address: 111 Queen's Park, Toronto, ON M5S 2C7",
        category: "Activities"
       
    }, {
        _id: "11",
        name: "TopGolf Canada",
        image: place_11,
        price: 45,
        description: "Address: 525 Bay St., Toronto, ON M5G 2L2",
        category: "Activities"
        
    }, {
        _id: "12",
        name: "Hondy Indy Toronto",
        image: place_12,
        price: 50,
        description: "Address: 210 Princes' Blvd, Toronto, ON M6K 3C3",
        category: "Activities"
       
    },
    {
        _id: "13",
        name: "MiMuseum",
        image: place_13,
        price: 28,
        description: "Address: 4175 Confederation Pkwy, Mississauga, ON L5B 0C6",
        category: "Activities"
        
    },
    {
        _id: "14",
        name: "Pursuit OCR",
        image: place_14,
        price: 25,
        description: "Address: 75 Westmore Dr Unit A, Etobicoke, ON M9V 3Y6",
        category: "Activities"
       
    }, {
        _id: "15",
        name: "Roller Pony",
        image: place_15,
        price: 19,
        description: "Address: 75 Westmore Dr Unit B, Etobicoke, ON M9V 3Y6",
        category: "Activities"
        
    }, {
        _id: "16",
        name: "Secret City Adventures",
        image: place_16,
        price: 28,
        description: "Address: 330 Walmer Road, Toronto M5R 2Y4",
        category: "Activities"
    }, {
        _id: "17",
        name: "Air Riderz Indoor Trampoline Park",
        image: place_17,
        price: 20,
        description: "Address: 570 Applewood Crescent #3, Concord, ON L4K 4B4",
        category: "Activities"
        
    }, {
        _id: "18",
        name: "Elora Gorge Tubing",
        image: place_18,
        price: 17,
        description: "Address: 7400 Wellington County Rd 21, Elora, ON N0B 1S0",
        category: "Activities"
        
    }, {
        _id: "19",
        name: "Upla Stouffville",
        image: place_19,
        price: 25,
        description: "Address: 3291 Stouffville Rd, Whitchurch-Stouffville, ON L4A 7X5",
        category: "Activities"
        
    }, {
        _id: "20",
        name: "Canada's Wonderland",
        image: place_20,
        price: 45,
        description: "1 Canada's Wonderland Drive, Maple, ON L6A 1S6",
        category: "Activities"
        
    }, {
        _id: "21",
        name: "Belfountain Conservation Area",
        image: place_21,
        price: 0,
        description: "819 Forks of the Credit Rd, Caledon, ON L7K 0E5",
        category: "Parks"
        
    }, {
        _id: "22",
        name: "Buttermilk Falls",
        image: place_22,
        price: 0,
        description: "Mountain Brow Blvd, Hamilton, ON L8K 5C7",
        category: "Parks"
        
    }, {
        _id: "23",
        name: "Crawford Lake",
        image: place_23,
        price: 0,
        description: "3115 Conservation Rd, Milton, ON",
        category: "Parks"
        
    }, {
        _id: "24",
        name: "Cup-Saucer Trail",
        image: place_24,
        price: 0,
        description: "4097 ON-540, Sheguiandah, ON P0P 1W0",
        category: "Parks"
        
    }, {
        _id: "25",
        name: "DeCew Trail",
        image: place_25,
        price: 0,
        description: "2714 Decew Rd, St. Catharines, ON L2R 6P7",
        category: "Parks"
        
    }, {
        _id: "26",
        name: "Elora Quarry Conservation Area",
        image: place_26,
        price: 0,
        description: "319 Wellington Rd 18, Elora, ON N0B 1S0",
        category: "Parks"
        
    }, {
        _id: "27",
        name: "Guild Park & Gardens",
        image: place_27,
        price: 0,
        description: "201 Guildwood Pkwy, Scarborough, ON M1E, Canada",
        category: "Parks"
        
    }, {
        _id: "28",
        name: "Lion's Head",
        image: place_28,
        price: 0,
        description: "Lion's Head, ON N0H 1W0",
        category: "Parks"
        
    }, {
        _id: "29",
        name: "TASC Tulip Farm",
        image: place_29,
        price: 0,
        description: "433 Sixteen Rd, Ridgeville, ON L0S 1M0",
        category: "Parks"
        
    }
    
]
